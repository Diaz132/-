﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Wpf3
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Owner.Close();
        }

        private void Info(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Пасеков Дмитрий 290ЭС");
        }

        private void Color(object sender, RoutedEventArgs e)
        {
            this.Background = new SolidColorBrush(Colors.Red);
        }

        private void Color1(object sender, RoutedEventArgs e)
        {
            this.Background = new SolidColorBrush(Colors.Red);
        }

        private void SetPenColor(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem menuItem)
            {
                string colorName = menuItem.Tag.ToString();
                switch (colorName)
                {
                    case "Red":
                        MYInkCanvas.DefaultDrawingAttributes.Color = Colors.Red;
                        break;
                    case "Green":
                        MYInkCanvas.DefaultDrawingAttributes.Color = Colors.Green;
                        break;
                    case "Yellow":
                        MYInkCanvas.DefaultDrawingAttributes.Color = Colors.Yellow;
                        break;
                    case "purple":
                        MYInkCanvas.DefaultDrawingAttributes.Color = Colors.Purple;
                        break;
                    case "Black":
                        MYInkCanvas.DefaultDrawingAttributes.Color = Colors.Black;
                        break;
                    case "Pink":
                        MYInkCanvas.DefaultDrawingAttributes.Color = Colors.Pink;
                        break;
                    default:
                        MYInkCanvas.DefaultDrawingAttributes.Color = Colors.Black;
                        break;

                }
            }
        }

        private void Eraser_Click(object sender, RoutedEventArgs e)
        {
            MYInkCanvas.EditingMode = InkCanvasEditingMode.EraseByStroke;
        }

        private void Pencil_Click(object sender, RoutedEventArgs e)
        {
            MYInkCanvas.EditingMode = InkCanvasEditingMode.Ink;
        }

        private void ChangeColor_Click(object sender, RoutedEventArgs e)
        {
            // This is just a placeholder for the menu item click
        }

        private void SizeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            MYInkCanvas.DefaultDrawingAttributes.Height = SizeSlider.Value;
            MYInkCanvas.DefaultDrawingAttributes.Width = SizeSlider.Value;
        }

        private void ToggleButton_Checked(object sender, RoutedEventArgs e)
        {
            // Logic for toggle button checked
        }

        private void ToggleButton_Checked_1(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Пасеков Дмитрий 290ЭС");
        }

        private void ColorComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (sender is ComboBox comboBox && comboBox.SelectedItem is ComboBoxItem selectedItem)
            {
                string selectedColor = selectedItem.Content.ToString();
                switch (selectedColor)
                {
                    case "Red":
                        MYInkCanvas.DefaultDrawingAttributes.Color = Colors.Red;
                        break;
                    case "Green":
                        MYInkCanvas.DefaultDrawingAttributes.Color = Colors.Green;
                        break;
                    case "Yellow":
                        MYInkCanvas.DefaultDrawingAttributes.Color = Colors.Yellow;
                        break;
                    case "purple":
                        MYInkCanvas.DefaultDrawingAttributes.Color = Colors.Purple;
                        break;
                    case "Black":
                        MYInkCanvas.DefaultDrawingAttributes.Color = Colors.Black;
                        break;
                    default:
                        MYInkCanvas.DefaultDrawingAttributes.Color = Colors.Black;
                        break;
                    case "Pink":
                        MYInkCanvas.DefaultDrawingAttributes.Color = Colors.Pink;
                        break;
                }
            }
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}