﻿using System.Windows;

namespace MultiEdit
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        // Обработчики для левых текстовых полей
        private void L1_LargeTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            R1_TextBox.Text = L1_TextBox.Text;
        }

        private void L1_SmallTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            R1_SmallTextBox.Text = L1_SmallTextBox.Text;
        }

        private void L2_SmallTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            R2_SmallTextBox.Text = L2_SmallTextBox.Text;
        }

        private void L3_SmallTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            R3_SmallTextBox.Text = L3_SmallTextBox.Text;
        }





        // Обработчики для правых текстовых полей
        private void R1_TextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            L1_TextBox.Text = R1_TextBox.Text;
        }

        private void R1_SmallTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            L1_SmallTextBox.Text = R1_SmallTextBox.Text;
        }

        private void R2_SmallTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            L2_SmallTextBox.Text = R2_SmallTextBox.Text;
        }

        private void R3_SmallTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            L3_SmallTextBox.Text = R3_SmallTextBox.Text;
        }
    }
}